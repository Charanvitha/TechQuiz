# Tech Quiz

A Pen created on CodePen.

Original URL: [https://codepen.io/Charanvitha-Deshini/pen/PwPPjQQ](https://codepen.io/Charanvitha-Deshini/pen/PwPPjQQ).

